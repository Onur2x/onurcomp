#!/usr/bin/env python3
import json
import sys

# JSON dosyasını oku
with open('d:/Onur_Yedek/mailler/fpcdeluxe/ccr/onurtheme/themes.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Her theme için eksik alanları ekle
for theme in data['themes']:
    # Button renkleri - baseColor'dan türet
    base_color = theme.get('baseColor', '#34495e')
    hover_color = theme.get('hoverColor', '#3498db')
    pressed_color = theme.get('pressedColor', '#2980b9')
    text_color = theme.get('textColor', '#ffffff')
    
    # Eksik alanları ekle
    if 'buttonColor' not in theme:
        theme['buttonColor'] = base_color
    if 'buttonHoverColor' not in theme:
        theme['buttonHoverColor'] = hover_color
    if 'buttonPressedColor' not in theme:
        theme['buttonPressedColor'] = pressed_color
    if 'buttonTextColor' not in theme:
        theme['buttonTextColor'] = text_color
    
    # LED renkleri
    if 'ledOffColor' not in theme:
        theme['ledOffColor'] = '#7f8c8d' if theme.get('name', '').lower() in ['carbon dark', 'minimal light', 'slate gray', 'silver chrome'] else '#666666'
    if 'ledOnColor' not in theme:
        theme['ledOnColor'] = '#2ecc71' if 'green' in theme.get('name', '').lower() else '#2ecc71'
    
    # Border width
    if 'borderWidth' not in theme:
        theme['borderWidth'] = theme.get('cornerRadius', 1)

# Güncellenmiş JSON'ı yaz
with open('d:/Onur_Yedek/mailler/fpcdeluxe/ccr/onurtheme/themes.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("Tüm themelere eksik alanlar eklendi.")
