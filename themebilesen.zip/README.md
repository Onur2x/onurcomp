# ONUR Theme Components

Modern, temalı Pascal bileşen koleksiyonu - BGRA Bitmap tabanlı

## Bileşenler

### TONURThemeButton
Temalı buton bileşeni
- Gradient desteği (Solid, Linear, Radial, Diamond)
- Hover, pressed, disabled durumları
- Carbon, Neon, Minimal temaları
- JSON tema dosyası desteği

### TONURThemeEdit
Temalı edit bileşeni
- Placeholder desteği
- Focus, hover durumları
- Temalı metin renkleri
- Klavye girişi desteği

### TONURThemePanel
Temalı panel bileşeni
- Gradient arka plan
- Gölge efektleri
- Cam efekti (Glass theme)
- Yuvarlatılmış köşeler

### TONURThemeLabel
Temalı etiket bileşeni
- Farklı stiller (Normal, Heading, Subheading, Caption)
- Metin gölgesi
- Hizalama seçenekleri
- Font boyutu ve stili kontrolü

### TONURThemeCheckBox
Temalı checkbox bileşeni
- Üç durum (Unchecked, Checked, Mixed)
- Temalı kutu ve check işareti
- Hover efektleri
- Klavye desteği (boşluk tuşu)

### TONURThemeProgressBar
Temalı progress bar bileşeni
- Üç stil (Linear, Circular, Segmented)
- Yüzade gösterimi
- Adımlı ilerleme
- Temalı renkler

### TONURThemeScrollBar
Temalı scroll bar bileşeni
- Yatay ve dikey orientasyon
- Sürükle-bırak desteği
- Hover efektleri
- Dinamik thumb boyutu

## Temalar

### Carbon Dark
- Koyu gri tonlar
- Mavi vurgular
- Modern görünüm
- Profesyonel tasarım

### Neon
- Cyan neon renkler
- Parlak efektler
- Gece modu
- Göz alıcı tasarım

### Minimal
- Sade renkler
- Temiz görünüm
- Basit tasarım
- Azaltılmış efektler

## Kullanım

```pascal
// Bileşen oluşturma
var
  ThemeButton: TONURThemeButton;
begin
  ThemeButton := TONURThemeButton.Create(Self);
  ThemeButton.Parent := Self;
  ThemeButton.Caption := 'Theme Button';
  ThemeButton.ApplyCarbonTheme;
end;

// Tema değiştirme
ThemeButton.ApplyNeonTheme;

// Özel tema yükleme
ThemeButton.LoadThemeFromFile('custom-theme.json');

// Tema kaydetme
ThemeButton.SaveThemeToFile('my-theme.json');
```

## Özellikler

- **BGRA Bitmap**: Yüksek performanslı grafik işleme
- **Gradient Desteği**: Çeşitli gradient türleri
- **Animasyon**: Smooth geçişler ve hover efektleri
- **Tema Sistemi**: JSON tabanlı tema yönetimi
- **Responsive**: Dinamik boyutlandırma
- **Cross-Platform**: Windows, Linux, macOS desteği

## Kurulum

1. ONUR paketini Lazarus'a yükleyin
2. BGRABitmap paketinin kurulu olduğundan emin olun
3. Paketi derleyin
4. Component Palette'te "ONUR Theme" sekmesi görünecektir

## Demo

`themebilesen/themedemo.lpr` projesini çalıştırarak tüm bileşenleri test edebilirsiniz.

## Lisans

LGPL with static linking exception

## Yazar

ONUR ERÇELEN
