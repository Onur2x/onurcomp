# ONUR 9 Slice Scaling Components

## Overview
This project provides 9 slice scaling components for Lazarus FPC using BGRABitmap. The components allow you to create scalable UI elements that maintain their corner proportions while stretching the edges and center.

## Components

### TONUR9SliceScaling
The core 9 slice scaling engine that handles the mathematical calculations and drawing operations.

**Properties:**
- `CropLeft`, `CropTop`, `CropRight`, `CropBottom`: Margins for the 9 slice areas
- `CropRects`: Get the crop margins as TRect

**Methods:**
- `SetCropMargins(ALeft, ATop, ARight, ABottom)`: Set all margins at once
- `Draw9Slice()`: Draw 9 slice to a BGRABitmap
- `Draw9SliceControl()`: Draw to TONURCustomControl
- `Draw9SliceGraphic()`: Draw to TONURGraphicControl

### TONURSkin9Slice
A TCustomControl-derived component that uses 9 slice scaling.

**Key Properties:**
- `NineSlice`: The 9 slice scaling engine
- `SourceRect`: Source rectangle from the skin image
- `Skindata`: Reference to TONURImg for skin data
- `Alpha`: Opacity control

### TONURSkin9SliceGraphic
A TGraphicsControl-derived component that uses 9 slice scaling.

Same properties as TONURSkin9Slice but derived from TGraphicsControl for lightweight usage.

## Installation

1. Open `onur.lpk` in Lazarus IDE
2. Compile and install the package
3. The components will appear in the "ONUR" component palette

## Usage Example

```pascal
// Create a 9 slice control
Skin9Slice := TONURSkin9Slice.Create(Self);
Skin9Slice.Parent := Self;
Skin9Slice.SetBounds(50, 50, 200, 100);

// Set up skin data
Skin9Slice.Skindata := SkinImg;

// Configure 9 slice margins (10px from each edge)
Skin9Slice.NineSlice.SetCropMargins(10, 10, 10, 10);

// Set source rectangle (256x256 source image)
Skin9Slice.SourceRect := Rect(0, 0, 256, 256);
```

## Demo Application

Run `demo9slice.lpr` to see a working demonstration of the 9 slice scaling components. The demo shows:

- Real-time crop margin adjustment
- Dynamic resizing
- Both CustomControl and GraphicsControl variants
- Sample skin generation with colored corners

## Technical Details

### 9 Slice Scaling Logic
The technique divides an image into 9 regions:

```
+-----+-----+-----+
| TL  |  T  | TR  |  (Top-Left, Top, Top-Right)
+-----+-----+-----+
| L   |  C  | R   |  (Left, Center, Right)
+-----+-----+-----+
| BL  |  B  | BR  |  (Bottom-Left, Bottom, Bottom-Right)
+-----+-----+-----+
```

- **Corners (TL, TR, BL, BR)**: Fixed size, never stretched
- **Edges (T, B, L, R)**: Stretched in one direction only
- **Center (C)**: Stretched in both directions

### Integration with Existing System
- Uses existing `TONURImg` for skin management
- Compatible with current `.osf` skin format
- Integrates with `TONURCustomCrop` system
- Maintains compatibility with existing component architecture

## Requirements

- Lazarus IDE
- Free Pascal Compiler (FPC)
- BGRABitmap package
- Existing ONUR component framework

## License

Same license as the ONUR component framework (LGPL with static linking exception).

## Author

ONUR ERÇELEN
