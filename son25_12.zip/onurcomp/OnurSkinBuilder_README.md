# ONUR Skin Builder v2.0 - Kullanım Kılavuzu

Modern skin oluşturma ve yönetim aracı.

## Özellikler

### Temel Özellikler
- Modern, kullanıcı dostu arayüz
- Görsel atlas editörü
- Gerçek zamanlı önizleme
- 9-slice desteği
- JSON formatı
- OSK export/import

### Kullanım

#### Yeni Skin Oluşturma
1. Skin Builder'ı açın
2. Atlas resmini yükleyin
3. Elementler ekleyin
4. Parçaları tanımlayın
5. Dikdörtgenleri belirleyin
6. Margin'leri ayarlayın
7. Kaydedin/export edin

#### Uygulamada Kullanım
```pascal
// Skin Manager oluştur
SkinManager := TONURSkinManager.Create(Self);
SkinManager.LoadSkinFromFile('skin.osk');

// Component'lere ata
MyButton.SkinManager := SkinManager;
MyButton.SkinElement := 'Button';
```

## Kurulum

1. BGRABitmap paketini kurun
2. OnurSkinBuilderPackage.lpk açın
3. "Use" -> "Install" tıklayın
4. Lazarus'u yeniden başlatın

## Destek

Sorularınız için: your-email@example.com
