# onurcomp
Lazarus components.
 Skins for Lazarus. The project is under construction and it is beta. Those who want to help in its development can participate. It is a public project. 
 License is MIT, ie It is free to change and use in all projects.
Uses BGRABitmap. Please check BGRABitmap licenses.
see. https://github.com/bgrabitmap/bgrabitmap


<p><b>Onurpagecontrol</b> = A component derived from TCustomcontrol. Pages are a rendered component and accept components on it.
<p><b>OnurGraphicsbutton </b> = button control derived from TGraphicscontrol.
<p><b>OnurCropbutton</b> = Button control derived from TCustomcontrol. With this control you can add buttons with cropped corners. Square, triangle, round or polygon etc.It can take shape according to the picture.
<p><b>Onurpanel </b> = A panel derived from Tcustomcontrol. Component can be put on it. And with the crop feature, you can create panels as you wish.
<p><b>Onurheaderpanel </b> = It is a derived panel from Tcustomcontrol. Component can be put on it. And with the crop feature, you can create panels as you wish.
<p><b>Onurcollapsedpanel </b>= A panel derived from Tcustomcontrol. Component can be put on it. And with the crop feature, you can create panels as you wish. It also has the ability to reduce or enlarge with a button on it. You set the button position
<p><b>Ourngraphicspanel</b> = A panel derived from TGraphicscontrol. Components cannot be placed on it. It is a "tshape"-like component.
<p><b>OnurEdit </b> = A component derived from TCustomcontrol. Developed from Lazarus customdrawn controls. It has crop property.It can take shape according to the picture.
<p><b>OnurMemo </b> = A component derived from TCustomcontrol. Developed from Lazarus customdrawn controls. It has crop property.It can take shape according to the picture.
<p><b>OnurSpinedit </b> = A component derived from TCustomcontrol.It has crop property.It can take shape according to the picture.
<p><b>OnurCombobox </b> = A component derived from TCustomcontrol. It has a crop feature. can take shape according to the picture. 
<p><b>OnurListbox </b> = A component derived from TCustomcontrol. It has a crop feature. can take shape according to the picture.
<p><b>Onurcolumlist </b> = A component derived from TCustomcontrol. It has a crop feature. can take shape according to the picture.Listing is done by creating columns. can be used like listview or stringrid for example. 
<p><b>OnurSwich </b> = A component derived from TGraphicControl. 
<p><b>OnurSrollbar </b> = A component derived from TCustomcontrol. It has a crop feature. can take shape according to the picture.
<p><b>OnurProgressbar </b> = A component derived from TGraphicControl.  
<p><b>OnurTrackbar </b> = A component derived from TGraphicControl.  
<p><b>OnurCheckbox </b> = A component derived from TGraphicControl.   
<p><b>OnurRadiobutton </b> = A component derived from TGraphicControl.   
<p><b>OnurLABEL </b> = A component derived from TGraphicControl.The label is created by taking the letters on the bitmap.Takes the fonts from the image.and animation can be created
<p><b>OnurNormalLABEL </b> = A component derived from TGraphicControl.is a component that has a label with the font on the component. animation can be created
<p><b>OnurLED </b> = A component derived from TGraphicControl. On off. 
<p><b>OnurKnob </b> = A component derived from TGraphicControl. Knob control. 
<p><img src="https://github.com/Onur2x/onurcomp/blob/master/3450.png"> 
<p><img src="https://github.com/Onur2x/onurcomp/blob/master/on1.png">
<p><img src="https://github.com/Onur2x/onurcomp/blob/master/on2.png">
<p><img src="https://github.com/Onur2x/onurcomp/blob/master/on3.png">
