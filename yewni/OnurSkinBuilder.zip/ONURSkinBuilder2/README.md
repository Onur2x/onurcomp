# ONUR Skin Builder 2.0

Modern, kompakt ve güçlü skin builder uygulaması için ONUR component kütüphanesi.

## 🎨 Özellikler

### ✨ Ana Özellikler
- **Modern Arayüz** - Temiz ve kullanıcı dostu arayüz
- **Gerçek ONUR Bileşenleri** - Tüm ONUR skin bileşenlerini destekler
- **Canlı Ön İzleme** - Değişiklikleri anında gör
- **Atlas Tabanlı** - Tek resim dosyası üzerinden çalışır
- **State Yönetimi** - Normal, Hover, Pressed, Disabled, Focused durumları
- **Renk Yönetimi** - Her state için özel renkler

### 🎯 Desteklenen Bileşenler
- ✅ **TONURButton** - Modern buton kontrolü
- ✅ **TONUREdit** - Metin giriş kontrolü  
- ✅ **TONURListBox** - Liste kontrolü
- ✅ **TONURProgressBar** - İlerleme çubuğu
- ✅ **TONURTrackBar** - Kaydırma çubuğu
- ✅ **TONURComboBox** - Açılır liste
- ✅ **TONURPageControl** - Sekme kontrolü
- ✅ **TONURScrollBar** - Kaydırma çubuğu
- ✅ **Panel, Label, CheckBox, RadioButton** - Standart kontroller

### 🔧 Araçlar
- **Atlas Editor** - Resim üzerinde seçim yapma
- **Zoom Kontrolü** - %10 - %500 zoom
- **Element Yönetimi** - Ekle, sil, kopyala
- **State Editor** - Her durum için özel ayarlar
- **Renk Paleti** - Kolay renk seçimi

## 📁 Dosya Yapısı

```
ONURSkinBuilder2/
├── ONURSkinBuilder2.lpr          # Ana program
├── ONURSkinBuilder2Main.pas      # Ana form
├── ONURSkinBuilder2.lfm         # Form tasarımı
├── ONURSkinBuilder2Register.pas  # IDE kaydı
└── README.md                     # Bu dosya
```

## 🚀 Kurulum

1. **Lazarus'u aç**
2. **Project > Open Project** seç
3. `ONURSkinBuilder2.lpr` dosyasını seç
4. **Run > Compile** veya **F9** tuşuna bas
5. Program derlenecek ve çalışacaktır

## 💡 Kullanım

### 🆕 Yeni Skin Oluştur
1. **File > New** menüsünü seç
2. **Skin Information** alanına bilgileri gir
3. **Load Atlas** butonu ile resim dosyasını yükle
4. **Add Element** butonu ile yeni bileşen ekle

### 🎨 Skin Uygulama
1. **Atlas üzerinde** fare ile seçim yap
2. **Element listesinden** ilgili bileşeni seç
3. **Properties panelinde** ayarları yap
4. **Colors bölümünden** renkleri seç
5. **Preview panelde** sonucu gör

### 💾 Kaydetme
1. **File > Save** veya **Ctrl+S**
2. Skin dosyasını `.onskin` formatında kaydet

### 📱 Ön İzleme
- **Preview panel**'de skin'in nasıl göründüğünü anında kontrol et
- **Preview butonu** ile tüm bileşenleri güncelle

## 🎯 State Yönetimi

Her bileşen için 5 farklı state desteklenir:

| State | Açıklama | Kullanım |
|-------|----------|----------|
| **Normal** | Normal durum | Varsayılan görünüm |
| **Hover** | Üzerine gelinince | Mouse hover efekti |
| **Pressed** | Basılıyken | Click efekti |
| **Disabled** | Pasif durum | Etkisiz görünüm |
| **Focused** | Odaklanınca | Klavye odak efekti |

## 🎨 Renk Yönetimi

Her state için özel renkler:
- **Background Color** - Arka plan rengi
- **Font Color** - Metin rengi
- **Border Color** - Kenarlık rengi (isteğe bağlı)

## 🔍 Atlas Editor

### 📐 Seçim Araçları
- **Mouse ile seçim** - Sol tuş basılı ve sürükle
- **Koordinat göster** - Status bar'da X,Y konumu
- **Zoom kontrolü** - Detaylı çalışma için

### 🖼️ Atlas Özellikleri
- **Desteklenen formatlar** - PNG, JPG, JPEG, BMP
- **Önerilen boyut** - 512x512 veya 1024x1024
- **Optimizasyon** - Otomatik boşluk temizleme

## 🛠️ Geliştirme

### 📋 TODO Listesi
- [ ] JSON kaydetme/yükleme
- [ ] Undo/Redo sistemi
- [ ] Template sistemi
- [ ] Export özellikleri (PNG, CSS)
- [ ] Auto-save özelliği
- [ ] Search/Replace element
- [ ] Batch operations
- [ ] Plugin sistemi

### 🔧 Teknik Detaylar
- **Framework** - Lazarus FreePascal
- **Grafik** - BGRABitmap
- **Format** - JSON + Atlas image
- **Bileşenler** - ONUR Component Library

## 📄 Lisans

Bu proje ONUR Component Library'nin bir parçasıdır ve aynı lisans altında dağıtılır.

## 🤝 Katkıda Bulunma

1. Fork yap
2. Feature branch oluştur (`git checkout -b feature/AmazingFeature`)
3. Commit yap (`git commit -m 'Add some AmazingFeature'`)
4. Push yap (`git push origin feature/AmazingFeature`)
5. Pull Request aç

## 📞 İletişim

- **Proje**: ONUR Component Library
- **Author**: ONUR Development Team
- **Version**: 2.0
- **Website**: [ONUR Components](https://github.com/onurcomponents)

---

**ONUR Skin Builder 2.0** - Modern skin geliştirme deneyimi! 🎨✨
